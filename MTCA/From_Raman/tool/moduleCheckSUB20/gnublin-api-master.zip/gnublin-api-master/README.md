gnublin-api
===========

Gnublin API
Many expansion boards with matching small console programs and a common API allow you to realize little applications or controls very fast. You look for the appropriate modules and test it with a little terminal tool. When you know how your first program should look like, you can easily write it by using the API.

The API should work on every embedded Linux board. Feel free to test it and send us feedback at:
info@embedded-projects.net

more information (complete documentation, reference, example programs etc.):
english: http://en.gnublin.org/index.php/API
deutsch: http://wiki.gnublin.org/index.php/API

Installation
============
checkout the INSTALL file for further instructions!
