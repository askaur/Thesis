var classgnublin__serial =
[
    [ "gnublin_serial", "classgnublin__serial.html#afe695b480ecb54c3b864bc03afc84643", null ],
    [ "gnublin_serial", "classgnublin__serial.html#a0cb22b9349decd7f6643d51b64e554f0", null ],
    [ "gnublin_serial", "classgnublin__serial.html#aa38d0af7c47416e70b494329d9c7efb0", null ],
    [ "fail", "classgnublin__serial.html#adc137988b6602ab6cdb73cebb269a63f", null ],
    [ "send", "classgnublin__serial.html#a352b96e2380fe037ad4fa58577393a7e", null ],
    [ "setBaudrate", "classgnublin__serial.html#a59f4072cad7726ceb6e48cf779fd910a", null ],
    [ "setDevicefile", "classgnublin__serial.html#a627298b9e6cebeaa4a58af4beede7c47", null ]
];