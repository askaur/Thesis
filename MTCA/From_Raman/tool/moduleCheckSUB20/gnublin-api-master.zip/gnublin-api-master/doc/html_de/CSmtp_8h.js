var CSmtp_8h =
[
    [ "gnublin_smtp", "classgnublin__smtp.html", "classgnublin__smtp" ],
    [ "__CSMTP_H__", "CSmtp_8h.html#ad8908307a0259eacb5633e30d619e3c5", null ],
    [ "BUFFER_SIZE", "CSmtp_8h.html#a6b20d41d6252e9871430c242cb1a56e7", null ],
    [ "COUNTER_VALUE", "CSmtp_8h.html#ad8292657d8dd14eecdab2c44dba0a1d3", null ],
    [ "INVALID_SOCKET", "CSmtp_8h.html#a26769957ec1a2beaf223f33b66ee64ab", null ],
    [ "MSG_SIZE_IN_MB", "CSmtp_8h.html#a9837d11374a325a3e8787dafed8ab8ed", null ],
    [ "SOCKET_ERROR", "CSmtp_8h.html#a633b0396ff93d336a088412a190a5072", null ],
    [ "TIME_IN_SEC", "CSmtp_8h.html#ad3beacef45904ca7d14e068ad4bede93", null ],
    [ "LPHOSTENT", "CSmtp_8h.html#a2ed3b578d11eb691fef5efd121a40c07", null ],
    [ "LPIN_ADDR", "CSmtp_8h.html#a5eb9fe09b2c4bdb778a3afe9f4a84655", null ],
    [ "LPSERVENT", "CSmtp_8h.html#a398c25afc7020446451d2b5ced021aa7", null ],
    [ "LPSOCKADDR", "CSmtp_8h.html#abd6f533b24db41dd613f5e03457a6b79", null ],
    [ "SOCKADDR_IN", "CSmtp_8h.html#a29046dc0232f0e5c70adbc25090d77b8", null ],
    [ "SOCKET", "CSmtp_8h.html#a8dc8083897335125630f1af5dafd5831", null ],
    [ "WORD", "CSmtp_8h.html#a197942eefa7db30960ae396d68339b97", null ],
    [ "CSmptXPriority", "CSmtp_8h.html#aa13c2215060aef424fdaefa05714bf9e", [
      [ "XPRIORITY_HIGH", "CSmtp_8h.html#aa13c2215060aef424fdaefa05714bf9eabf8f58f907c17c79411ee353ecc95f50", null ],
      [ "XPRIORITY_NORMAL", "CSmtp_8h.html#aa13c2215060aef424fdaefa05714bf9ea7f4e97e5aee0f59cb15e739a6284176f", null ],
      [ "XPRIORITY_LOW", "CSmtp_8h.html#aa13c2215060aef424fdaefa05714bf9eaf838b63a3181971fb9b981a331957963", null ]
    ] ],
    [ "BOUNDARY_TEXT", "CSmtp_8h.html#a660eb6ce768604345522904ebef08b41", null ]
];