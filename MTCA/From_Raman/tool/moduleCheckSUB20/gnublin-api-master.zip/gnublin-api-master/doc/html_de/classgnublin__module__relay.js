var classgnublin__module__relay =
[
    [ "gnublin_module_relay", "classgnublin__module__relay.html#af8e338c18e779ece93cff70f8cbe2c8c", null ],
    [ "fail", "classgnublin__module__relay.html#aa4a3680991a5c0fbc1045d8f9224041c", null ],
    [ "getErrorMessage", "classgnublin__module__relay.html#ab0629038b95e2eddb67204ef123772cc", null ],
    [ "readState", "classgnublin__module__relay.html#a7ebba58d1c63e6b507cdc1d109de1277", null ],
    [ "setAddress", "classgnublin__module__relay.html#a43dfb0e6141823177301a5676b78e4b7", null ],
    [ "setDevicefile", "classgnublin__module__relay.html#a7db8134476a8a10f2a92e7e8470f4754", null ],
    [ "switchPin", "classgnublin__module__relay.html#a2d91afaed1237e308b5afdbb06a8a606", null ]
];