var classgnublin__module__dogm =
[
    [ "gnublin_module_dogm", "classgnublin__module__dogm.html#a41e540957ba0d3ea126b33c1a4ef7ef1", null ],
    [ "clear", "classgnublin__module__dogm.html#ab49a40d16cd23f47350ac8a5477eb1b9", null ],
    [ "controlDisplay", "classgnublin__module__dogm.html#a93a0c10446511bfeea5ae6842930c89b", null ],
    [ "fail", "classgnublin__module__dogm.html#ad33768709796e1cdf120fe5a0a47f70e", null ],
    [ "getErrorMessage", "classgnublin__module__dogm.html#aa1224e3f7ae5db4b820c6eff7deddd20", null ],
    [ "init", "classgnublin__module__dogm.html#a8165ef375f35797a8750a4dc3c814e21", null ],
    [ "offset", "classgnublin__module__dogm.html#a21fb00e088162c0568ffceea407e7530", null ],
    [ "print", "classgnublin__module__dogm.html#ab11a6ba2fcfdeb3c256d7e1755d7ca32", null ],
    [ "print", "classgnublin__module__dogm.html#aeedef465e60b63fbf3443d711065debe", null ],
    [ "print", "classgnublin__module__dogm.html#ade29bdc1a5302ca1a5fe65256a7a90a8", null ],
    [ "returnHome", "classgnublin__module__dogm.html#a7caae14916fc9dac10a5d6a9a470c36e", null ],
    [ "setCS", "classgnublin__module__dogm.html#a75cfabf06be90c7efa6b288a6b4ab1c0", null ],
    [ "setRsPin", "classgnublin__module__dogm.html#afdbfe7f1ba1b40bbc386bef55668a53d", null ],
    [ "shift", "classgnublin__module__dogm.html#afaa41235e01a2e2b09be139af0d0f9de", null ]
];