var printer__temp_8cpp =
[
    [ "get_temperature", "printer__temp_8cpp.html#ad74ffeabbe77c29f5a1335f3b0d174b1", null ],
    [ "main", "printer__temp_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "my_handler", "printer__temp_8cpp.html#a13848d945610347db87a059fe0b43f35", null ],
    [ "adc", "printer__temp_8cpp.html#afcf90d1e2256fe3e75222a1a9d9bd181", null ],
    [ "display", "printer__temp_8cpp.html#a30e11d944dd8cedb9a31abb973d33f86", null ],
    [ "gpio", "printer__temp_8cpp.html#ad08c6bc10fc2aff29a0db92027decdbb", null ]
];