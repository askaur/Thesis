var serial_8cpp =
[
    [ "BAUDRATE", "serial_8cpp.html#a734bbab06e1a9fd2e5522db0221ff6e3", null ],
    [ "SERIALDEVICE", "serial_8cpp.html#a3e59945a8788831cb4149fe1cd696721", null ]
];