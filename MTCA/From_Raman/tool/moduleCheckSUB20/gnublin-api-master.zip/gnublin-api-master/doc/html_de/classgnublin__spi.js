var classgnublin__spi =
[
    [ "gnublin_spi", "classgnublin__spi.html#ac790b3cfaba3dfeca1c8a39704e65622", null ],
    [ "~gnublin_spi", "classgnublin__spi.html#a5a40d501e737bcdda7d9218e7bb3c7fc", null ],
    [ "fail", "classgnublin__spi.html#a9b897815f1ed73816c947e3a024eb3e0", null ],
    [ "getErrorMessage", "classgnublin__spi.html#a605feea3ee93a0e0c9411f36639fc0f6", null ],
    [ "getLength", "classgnublin__spi.html#a1145f5b9a9c350bca5110bb076309733", null ],
    [ "getLSB", "classgnublin__spi.html#aeb550ebd56e83aac5fe77813edb59fe6", null ],
    [ "getMode", "classgnublin__spi.html#a8e6935bcd95dd9c3f15947f8bdc7ccd6", null ],
    [ "getSpeed", "classgnublin__spi.html#afde01e3c3444cbd36652aab8871513e6", null ],
    [ "message", "classgnublin__spi.html#aa169a288e8d28fd08a64352adf5c099e", null ],
    [ "receive", "classgnublin__spi.html#a9815912c27d892499ba1e8907794bd26", null ],
    [ "send", "classgnublin__spi.html#afff249ca377350571ea1b88786144c3e", null ],
    [ "setCS", "classgnublin__spi.html#a54d51354605b76945ed458c4df439d7c", null ],
    [ "setLength", "classgnublin__spi.html#a25cbef19a01866710adf83c08a4e7ee8", null ],
    [ "setLSB", "classgnublin__spi.html#adfe7447cc567e81ac2b58417f45579f2", null ],
    [ "setMode", "classgnublin__spi.html#a1baaa0ac7d511131a7cde508fe1b6248", null ],
    [ "setSpeed", "classgnublin__spi.html#aa41d3b1e523e775f77c912533ce501ee", null ]
];